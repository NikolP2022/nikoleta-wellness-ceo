# Nikoleta Wellness CEO

Προσωπικό web app για CRM πελατών, Tanita μετρήσεις, planner και οικονομική καταγραφή.

## Χρήση
Ανεβάστε όλα τα αρχεία στο repository και ενεργοποιήστε GitHub Pages από το branch `main` και τον φάκελο `/ (root)`.
