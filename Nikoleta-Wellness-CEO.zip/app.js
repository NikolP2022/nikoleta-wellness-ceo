const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const state=JSON.parse(localStorage.getItem('nwceo')||'{"clients":[],"tasks":[],"income":[]}');
const save=()=>localStorage.setItem('nwceo',JSON.stringify(state));
function nav(view){$$('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view)); render(view)}
function render(view='dashboard'){
 const app=$('#app');
 if(view==='dashboard') app.innerHTML=dashboard();
 if(view==='clients') app.innerHTML=clients();
 if(view==='tanita') app.innerHTML=tanita();
 if(view==='planner') app.innerHTML=planner();
 if(view==='finance') app.innerHTML=finance();
 bind();
}
function dashboard(){return `<h1>Καλώς ήρθες, Nikoleta ✨</h1><p class="muted">Το προσωπικό σου Wellness CEO dashboard.</p>
<div class="grid">
<div class="card"><span class="muted">Πελάτες</span><div class="stat">${state.clients.length}</div><span class="pill">Ενεργό CRM</span></div>
<div class="card"><span class="muted">Σημερινές εργασίες</span><div class="stat">${state.tasks.filter(t=>t.date===new Date().toISOString().slice(0,10)&&!t.done).length}</div></div>
<div class="card"><span class="muted">Έσοδα</span><div class="stat">${state.income.reduce((a,x)=>a+Number(x.amount||0),0).toFixed(2)} €</div></div>
<div class="card"><span class="muted">Επόμενος στόχος</span><div class="stat">CEO</div><span class="pill">Συνέπεια κάθε μέρα</span></div>
</div>
<div class="card" style="margin-top:20px"><div class="row"><h2>Γρήγορες ενέργειες</h2><button class="primary" id="quickClient">＋ Πελάτης</button></div>
<p>Κράτησε εδώ πελάτες, Tanita μετρήσεις, follow-ups, planner και οικονομικά — όλα σε ένα σημείο.</p></div>`}
function clients(){return `<div class="row"><div><h1>Πελάτες</h1><p class="muted">CRM και σημειώσεις πελατών</p></div><button class="primary" id="quickClient">＋ Νέος πελάτης</button></div>
<div class="card"><table class="table"><thead><tr><th>Όνομα</th><th>Τηλέφωνο</th><th>Email</th><th></th></tr></thead><tbody>
${state.clients.length?state.clients.map((c,i)=>`<tr><td><b>${esc(c.name)}</b><br><span class="muted">${esc(c.notes||'')}</span></td><td>${esc(c.phone||'-')}</td><td>${esc(c.email||'-')}</td><td><button data-del="${i}">Διαγραφή</button></td></tr>`).join(''):`<tr><td colspan="4" class="empty">Δεν υπάρχουν πελάτες ακόμη.</td></tr>`}</tbody></table></div>`}
function tanita(){return `<h1>Tanita</h1><p class="muted">Καταγραφή σωματομετρήσεων ανά πελάτη.</p><div class="card"><form id="tanitaForm"><select name="client" required><option value="">Επίλεξε πελάτη</option>${state.clients.map((c,i)=>`<option value="${i}">${esc(c.name)}</option>`).join('')}</select><input name="date" type="date" value="${new Date().toISOString().slice(0,10)}" required><input name="weight" type="number" step=".1" placeholder="Βάρος (kg)" required><input name="fat" type="number" step=".1" placeholder="Λίπος (%)"><input name="muscle" type="number" step=".1" placeholder="Μυϊκή μάζα (kg)"><input name="water" type="number" step=".1" placeholder="Νερό (%)"><input name="visceral" type="number" step=".1" placeholder="Σπλαχνικό λίπος"><button class="primary">Αποθήκευση μέτρησης</button></form></div>
<div class="card" style="margin-top:16px"><h2>Σημείωση</h2><p>Οι μετρήσεις αποθηκεύονται τοπικά σε αυτή τη συσκευή.</p></div>`}
function planner(){return `<h1>CEO Planner</h1><p class="muted">Οργάνωσε την ημέρα σου.</p><div class="card"><form id="taskForm"><input name="task" placeholder="Νέα εργασία..." required><input name="date" type="date" value="${new Date().toISOString().slice(0,10)}"><button class="primary">＋ Προσθήκη</button></form></div><div class="card" style="margin-top:16px"><h2>Εργασίες</h2>${state.tasks.length?state.tasks.map((t,i)=>`<div class="check"><input type="checkbox" data-task="${i}" ${t.done?'checked':''}><span>${esc(t.task)} <span class="muted">— ${t.date}</span></span></div>`).join(''):'<div class="empty">Δεν έχεις εργασίες ακόμη.</div>'}</div>`}
function finance(){return `<h1>Οικονομικά</h1><p class="muted">Απλή καταγραφή εσόδων.</p><div class="grid"><div class="card"><span class="muted">Σύνολο</span><div class="stat">${state.income.reduce((a,x)=>a+Number(x.amount||0),0).toFixed(2)} €</div></div></div><div class="card" style="margin-top:16px"><form id="incomeForm"><input name="description" placeholder="Περιγραφή" required><input name="amount" type="number" step=".01" placeholder="Ποσό €" required><button class="primary">＋ Καταχώρηση</button></form></div>`}
function bind(){
 $('#quickClient')?.addEventListener('click',()=>$('#clientDialog').showModal());
 $('#addClientTop')?.addEventListener('click',()=>$('#clientDialog').showModal());
 $$('[data-del]').forEach(b=>b.onclick=()=>{state.clients.splice(+b.dataset.del,1);save();render('clients')});
 $('#tanitaForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);const c=state.clients[f.get('client')]; if(c){c.tanita=c.tanita||[];c.tanita.push(Object.fromEntries(f));save();e.target.reset();alert('Η μέτρηση αποθηκεύτηκε!')}});
 $('#taskForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);state.tasks.push({task:f.get('task'),date:f.get('date'),done:false});save();render('planner')});
 $$('[data-task]').forEach(x=>x.onchange=()=>{state.tasks[+x.dataset.task].done=x.checked;save()});
 $('#incomeForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);state.income.push({description:f.get('description'),amount:f.get('amount')});save();render('finance')});
}
$('#clientForm').addEventListener('submit',e=>{if(e.submitter?.value!=='ok')return; e.preventDefault();const f=new FormData(e.target);state.clients.push(Object.fromEntries(f));save();$('#clientDialog').close();render('clients')});
$$('nav button').forEach(b=>b.onclick=()=>nav(b.dataset.view));
function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
render();