const KEY="nikoleta_wellness_ceo_v5";
let db=JSON.parse(localStorage.getItem(KEY)||'{"clients":[],"appointments":[],"tasks":[],"partners":[],"finance":[],"tanita":[]}');
let currentView="home", selectedClient=null;

function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function money(n){return Number(n||0).toFixed(2)+" €"}
function clientName(id){return db.clients.find(c=>c.id===id)?.name||"—"}
function render(){
  document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.view===currentView));
  const a=document.getElementById("app");
  const views={home:home,clients:clients,appointments:appointments,partners:partners,tanita:tanita,planner:planner,finance:finance,backup:backup};
  a.innerHTML=(views[currentView]||home)();
  bind();
}
function home(){
 const income=db.finance.filter(x=>x.type==="income").reduce((s,x)=>s+Number(x.amount),0);
 const expense=db.finance.filter(x=>x.type==="expense").reduce((s,x)=>s+Number(x.amount),0);
 return `<div class="hero"><h1>Καλώς ήρθες, Nikoleta ✨</h1><p class="muted">Το προσωπικό σου Wellness CEO dashboard.</p></div>
 <div class="grid">
 <div class="card">Πελάτες<div class="stat">${db.clients.length}</div><span class="muted">CRM</span></div>
 <div class="card">Σημερινές εργασίες<div class="stat">${db.tasks.filter(t=>!t.done).length}</div></div>
 <div class="card">Καθαρό αποτέλεσμα<div class="stat">${money(income-expense)}</div></div>
 <div class="card">Ραντεβού<div class="stat">${db.appointments.filter(x=>x.date===new Date().toISOString().slice(0,10)).length}</div></div>
 </div>
 <div class="section card"><h2>Γρήγορες ενέργειες</h2><div class="actions">
 <button class="btn green" data-action="newClient">＋ Νέος πελάτης</button>
 <button class="btn" data-view2="appointments">📅 Νέο ραντεβού</button>
 <button class="btn" data-view2="planner">＋ Εργασία</button></div></div>`;
}
function clients(){
 return `<div class="profile-head"><div><h1>Πελάτες</h1><p class="muted">Πλήρης καρτέλα πελάτη — όλα σε ένα σημείο.</p></div><button class="primary" data-action="newClient">＋ Νέος πελάτης</button></div>
 <div class="section">${db.clients.length?`<table><thead><tr><th>Πελάτης</th><th>Τύπος</th><th>Επικοινωνία</th><th>Follow-up</th><th></th></tr></thead><tbody>${db.clients.map(c=>`<tr><td><strong>${esc(c.name)}</strong><br><span class="badge">ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ</span></td><td>${esc(c.type||"Πελάτης")}</td><td>${esc(c.phone||"")}<br>${esc(c.email||"")}</td><td>${esc(c.followup||"—")}</td><td><button class="btn" data-open="${c.id}">Άνοιγμα καρτέλας</button></td></tr>`).join("")}</tbody></table>`:`<div class="empty">Δεν υπάρχουν πελάτες ακόμη.</div>`}</div>`;
}
function appointments(){
 return `<div class="profile-head"><div><h1>📅 Ραντεβού</h1><p class="muted">Ημερήσιο πρόγραμμα και υπενθυμίσεις.</p></div><button class="primary" data-action="newAppointment">＋ Νέο ραντεβού</button></div>
 <div class="section">${db.appointments.length?`<table><thead><tr><th>Ημερομηνία</th><th>Ώρα</th><th>Πελάτης</th><th>Τύπος</th><th>Υπενθύμιση</th></tr></thead><tbody>${db.appointments.sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.time)}</td><td>${esc(clientName(x.clientId))}</td><td>${esc(x.type)}</td><td>${x.reminder?"15′ πριν":"—"}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Δεν υπάρχουν ραντεβού ακόμη.</div>`}</div>`;
}
function partners(){
 return `<div class="profile-head"><div><h1>🤝 Συνεργάτες</h1><p class="muted">Νέα μέλη και συνεργάτες σε ξεχωριστή λίστα.</p></div><button class="primary" data-action="newPartner">＋ Νέος συνεργάτης</button></div>
 <div class="section">${db.partners.length?`<table><thead><tr><th>Όνομα</th><th>Τηλέφωνο</th><th>Ρόλος</th><th>Follow-up</th></tr></thead><tbody>${db.partners.map(p=>`<tr><td>${esc(p.name)}</td><td>${esc(p.phone)}</td><td>${esc(p.role)}</td><td>${esc(p.followup||"—")}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Δεν υπάρχουν συνεργάτες ακόμη.</div>`}</div>`;
}
function tanita(){
 return `<h1>⚖️ Tanita</h1><p class="muted">Καταγραφή και ιστορικό σωματομετρήσεων ανά πελάτη.</p>
 <div class="section card"><button class="primary" data-action="newTanita">＋ Αποθήκευση μέτρησης</button></div>
 <div class="section">${db.tanita.length?`<table><thead><tr><th>Πελάτης</th><th>Ημερομηνία</th><th>Βάρος</th><th>Λίπος</th><th>Μύες</th><th>Σπλαχνικό</th></tr></thead><tbody>${db.tanita.map(t=>`<tr><td>${esc(clientName(t.clientId))}</td><td>${esc(t.date)}</td><td>${esc(t.weight)} kg</td><td>${esc(t.fat)}%</td><td>${esc(t.muscle)} kg</td><td>${esc(t.visceral)}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Δεν υπάρχουν μετρήσεις ακόμη.</div>`}</div>`;
}
function planner(){
 return `<div class="profile-head"><div><h1>CEO Planner</h1><p class="muted">Οργάνωσε τις καθημερινές ενέργειές σου.</p></div><button class="primary" data-action="newTask">＋ Προσθήκη</button></div>
 <div class="section">${db.tasks.length?`<div class="grid">${db.tasks.map((t,i)=>`<div class="card"><label><input type="checkbox" data-task="${i}" ${t.done?"checked":""}> ${esc(t.text)}</label></div>`).join("")}</div>`:`<div class="empty">Δεν έχεις εργασίες ακόμη.</div>`}</div>`;
}
function finance(){
 const income=db.finance.filter(x=>x.type==="income").reduce((s,x)=>s+Number(x.amount),0), expense=db.finance.filter(x=>x.type==="expense").reduce((s,x)=>s+Number(x.amount),0);
 return `<h1>Οικονομικά</h1><p class="muted">Έσοδα, έξοδα και καθαρό αποτέλεσμα.</p><div class="grid">
 <div class="card">Έσοδα<div class="stat">${money(income)}</div></div><div class="card">Έξοδα<div class="stat">${money(expense)}</div></div><div class="card">Καθαρό<div class="stat">${money(income-expense)}</div></div></div>
 <div class="section actions"><button class="btn green" data-action="income">＋ Έσοδο</button><button class="btn" data-action="expense">− Έξοδο</button></div>
 <div class="section">${db.finance.length?`<table><thead><tr><th>Ημερομηνία</th><th>Τύπος</th><th>Περιγραφή</th><th>Ποσό</th></tr></thead><tbody>${db.finance.map(x=>`<tr><td>${esc(x.date)}</td><td>${x.type==="income"?"Έσοδο":"Έξοδο"}</td><td>${esc(x.text)}</td><td>${money(x.amount)}</td></tr>`).join("")}</tbody></table>`:""}</div>`;
}
function backup(){
 return `<h1>Αντίγραφο ασφαλείας</h1><p class="muted">Εξαγωγή ή εισαγωγή όλων των δεδομένων της εφαρμογής.</p>
 <div class="card actions"><button class="primary" data-action="export">⬇ Εξαγωγή δεδομένων</button><label class="btn">⬆ Εισαγωγή δεδομένων<input id="importFile" type="file" accept=".json" hidden></label><button class="btn" data-action="clear">Διαγραφή όλων</button></div>`;
}
function openModal(title,body){
 document.getElementById("modalRoot").innerHTML=`<div class="modal"><div class="modalbox"><div class="modalhead"><h2>${title}</h2><button class="close" data-close>×</button></div>${body}</div></div>`;
}
function form(fields,submitLabel="Αποθήκευση"){return `<form id="modalForm" class="form">${fields.join("")}<div class="field full"><button class="primary" type="submit">${submitLabel}</button></div></form>`}
function fld(label,name,type="text",extra=""){return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" ${extra}></div>`}
function clientForm(){
 openModal("Νέος πελάτης",form([
 fld("Ονοματεπώνυμο","name","text",'required'),fld("Τηλέφωνο","phone"),fld("Email","email"),fld("Τύπος","type","text",'value="Πελάτης"'),
 fld("Follow-up","followup","date"),`<div class="field full"><label>Προσωπική αξιολόγηση / σημειώσεις</label><textarea name="notes"></textarea></div>`
 ]));
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));db.clients.push({id:crypto.randomUUID(),...d,created:new Date().toISOString()});document.getElementById("modalRoot").innerHTML="";save()};
}
function appointmentForm(){
 const opts=db.clients.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
 openModal("Νέο ραντεβού",form([fld("Ημερομηνία","date","date",'required'),fld("Ώρα","time","time",'required'),`<div class="field"><label>Πελάτης</label><select name="clientId">${opts}</select></div>`,fld("Τύπος ραντεβού","type","text",'value="Προσωπική αξιολόγηση"'),`<div class="field full"><label><input type="checkbox" name="reminder" checked> Υπενθύμιση 15 λεπτά πριν</label></div>`]));
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.reminder=e.target.reminder.checked;db.appointments.push(d);document.getElementById("modalRoot").innerHTML="";save()};
}
function partnerForm(){
 openModal("Νέος συνεργάτης",form([fld("Ονοματεπώνυμο","name","text",'required'),fld("Τηλέφωνο","phone"),fld("Ρόλος","role","text",'value="Υποψήφιος συνεργάτης"'),fld("Follow-up","followup","date")]));
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();db.partners.push(Object.fromEntries(new FormData(e.target)));document.getElementById("modalRoot").innerHTML="";save()};
}
function tanitaForm(){
 const opts=db.clients.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
 openModal("Καταγραφή Tanita",form([`<div class="field"><label>Πελάτης</label><select name="clientId" required>${opts}</select></div>`,fld("Ημερομηνία","date","date",'required'),fld("Βάρος (kg)","weight","number",'step="0.1"'),fld("Σωματικό λίπος (%)","fat","number",'step="0.1"'),fld("Μυϊκή μάζα (kg)","muscle","number",'step="0.1"'),fld("Σπλαχνικό λίπος","visceral","number",'step="0.1"')]));
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();db.tanita.push(Object.fromEntries(new FormData(e.target)));document.getElementById("modalRoot").innerHTML="";save()};
}
function taskForm(){openModal("Νέα εργασία",form([fld("Εργασία","text","text",'required') ]));document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));db.tasks.push({text:d.text,done:false});document.getElementById("modalRoot").innerHTML="";save()}}
function financeForm(type){openModal(type==="income"?"Νέο έσοδο":"Νέο έξοδο",form([fld("Ημερομηνία","date","date",'value="'+new Date().toISOString().slice(0,10)+'"'),fld("Περιγραφή","text","text",'required'),fld("Ποσό (€)","amount","number",'step="0.01" required')]));document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.type=type;db.finance.push(d);document.getElementById("modalRoot").innerHTML="";save()}}
function clientProfile(id){
 const c=db.clients.find(x=>x.id===id); if(!c)return;
 const measurements=db.tanita.filter(t=>t.clientId===id), appts=db.appointments.filter(a=>a.clientId===id);
 openModal("ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ — "+esc(c.name),`
 <div class="badge">ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ</div>
 <div class="tabs"><button class="active">Στοιχεία</button><button>Ραντεβού (${appts.length})</button><button>Tanita (${measurements.length})</button><button>Διατροφικό πρόγραμμα</button><button>Follow-ups</button><button>Παραγγελίες / Πληρωμές</button><button>Σημειώσεις</button></div>
 <div class="grid"><div class="card"><b>Επικοινωνία</b><p>${esc(c.phone||"—")}<br>${esc(c.email||"—")}</p></div><div class="card"><b>Follow-up</b><p>${esc(c.followup||"—")}</p></div><div class="card"><b>Τύπος</b><p>${esc(c.type||"Πελάτης")}</p></div></div>
 <div class="section card"><h3>Σημειώσεις / προσωπική αξιολόγηση</h3><p>${esc(c.notes||"—")}</p></div>
 <div class="section card"><h3>Ιστορικό Tanita</h3>${measurements.length?measurements.map(t=>`<p>${esc(t.date)} — ${esc(t.weight)} kg · ${esc(t.fat)}% λίπος · ${esc(t.muscle)} kg μύες</p>`).join(""):"<p class='muted'>Δεν υπάρχουν μετρήσεις.</p>"}</div>
 <div class="section actions"><button class="primary" data-pdf="${id}">📄 Δημιουργία PDF πλήρους καρτέλας</button></div>`);
}
function makePdf(id){
 const c=db.clients.find(x=>x.id===id), m=db.tanita.filter(x=>x.clientId===id), a=db.appointments.filter(x=>x.clientId===id);
 const html=`<!doctype html><html lang="el"><head><meta charset="utf-8"><title>Προσωπική Αξιολόγηση - ${esc(c.name)}</title><style>body{font-family:Arial;padding:35px;color:#17351f}h1{color:#00843d}.box{border:1px solid #ddd;border-radius:10px;padding:15px;margin:12px 0}table{width:100%;border-collapse:collapse}td,th{padding:8px;border:1px solid #ddd;text-align:left}</style></head><body><h1>🌿 Nikoleta Wellness CEO</h1><h2>ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ</h2><div class="box"><b>Πελάτης:</b> ${esc(c.name)}<br><b>Τηλέφωνο:</b> ${esc(c.phone||"—")}<br><b>Email:</b> ${esc(c.email||"—")}<br><b>Follow-up:</b> ${esc(c.followup||"—")}</div><div class="box"><h3>Σημειώσεις</h3>${esc(c.notes||"—")}</div><div class="box"><h3>Tanita</h3><table><tr><th>Ημερομηνία</th><th>Βάρος</th><th>Λίπος</th><th>Μύες</th><th>Σπλαχνικό</th></tr>${m.map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.weight)}</td><td>${esc(x.fat)}</td><td>${esc(x.muscle)}</td><td>${esc(x.visceral)}</td></tr>`).join("")}</table></div><div class="box"><h3>Ραντεβού</h3>${a.map(x=>`<p>${esc(x.date)} ${esc(x.time)} — ${esc(x.type)}</p>`).join("")||"—"}</div><script>window.onload=()=>window.print()</script></body></html>`;
 const w=window.open("","_blank"); w.document.write(html); w.document.close();
}
function bind(){
 document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>{currentView=b.dataset.view;render()});
 document.querySelectorAll("[data-view2]").forEach(b=>b.onclick=()=>{currentView=b.dataset.view2;render()});
 document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>({newClient:clientForm,newAppointment:appointmentForm,newPartner:partnerForm,newTanita:tanitaForm,newTask:taskForm,income:()=>financeForm("income"),expense:()=>financeForm("expense"),export:exportData,clear:clearData}[b.dataset.action]||(()=>{}))());
 document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>clientProfile(b.dataset.open));
 document.querySelectorAll("[data-pdf]").forEach(b=>b.onclick=()=>makePdf(b.dataset.pdf));
 document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>document.getElementById("modalRoot").innerHTML="");
 document.querySelectorAll("[data-task]").forEach(b=>b.onchange=()=>{db.tasks[Number(b.dataset.task)].done=b.checked;save()});
 const imp=document.getElementById("importFile"); if(imp)imp.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();alert("Η εισαγωγή ολοκληρώθηκε.");}catch{alert("Το αρχείο δεν είναι έγκυρο JSON.");}};r.readAsText(f)};
}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="nikoleta-wellness-backup.json";a.click();URL.revokeObjectURL(a.href)}
function clearData(){if(confirm("Να διαγραφούν όλα τα δεδομένα;")){db={clients:[],appointments:[],tasks:[],partners:[],finance:[],tanita:[]};save()}}
document.getElementById("newClientBtn").onclick=clientForm;
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
render();
