const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
const KEY='nwceo_v4';
const today=()=>new Date().toISOString().slice(0,10);
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2);
const esc=x=>String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const money=n=>Number(n||0).toLocaleString('el-GR',{style:'currency',currency:'EUR'});

const initial={
  clients:[],appointments:[],tasks:[],income:[],expenses:[],measurements:[],orders:[]
};

function load(){
  try{
    const raw=JSON.parse(localStorage.getItem(KEY)||'{}');
    return {
      ...structuredClone(initial),
      ...raw,
      clients:Array.isArray(raw.clients)?raw.clients:[],
      appointments:Array.isArray(raw.appointments)?raw.appointments:[],
      tasks:Array.isArray(raw.tasks)?raw.tasks:[],
      income:Array.isArray(raw.income)?raw.income:[],
      expenses:Array.isArray(raw.expenses)?raw.expenses:[],
      measurements:Array.isArray(raw.measurements)?raw.measurements:[],
      orders:Array.isArray(raw.orders)?raw.orders:[]
    };
  }catch{return structuredClone(initial)}
}
let state=load();
let currentClientId=null;

function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function client(id){return state.clients.find(c=>c.id===id)}
function initials(name=''){return name.trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'N'}
function lastMeasurement(id){return state.measurements.filter(m=>m.clientId===id).sort((a,b)=>b.date.localeCompare(a.date))[0]}
function nav(view){$$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));render(view)}
function render(view='dashboard'){
  const pages={dashboard,appointments,clients,tanita,more,finance,planner,backup,clientDetail};
  $('#app').innerHTML=(pages[view]||dashboard)();
  bind();
  updateBadge();
}
function updateBadge(){
  const n=state.appointments.filter(a=>a.date===today()).length+
          state.clients.filter(c=>c.nextFollowUp&&c.nextFollowUp<=today()).length;
  $('#notifyBadge').textContent=n;
}

function dashboard(){
  const due=state.clients.filter(c=>c.nextFollowUp&&c.nextFollowUp<=today()).length;
  const todayAp=state.appointments.filter(a=>a.date===today()).length;
  const income=state.income.reduce((a,x)=>a+Number(x.amount||0),0);
  const expenses=state.expenses.reduce((a,x)=>a+Number(x.amount||0),0);
  return `<section class="hero">
    <div class="eyebrow">PERSONAL WELLNESS MANAGEMENT</div>
    <h1>Καλώς ήρθες, Νικόλετα 🌿</h1>
    <p>Όλη η καθημερινή λειτουργία του Wellness business σου, οργανωμένη σε ένα σημείο.</p>
  </section>
  <div class="section-title"><h2>Σήμερα</h2><span class="muted">${new Date().toLocaleDateString('el-GR',{weekday:'long',day:'numeric',month:'long'})}</span></div>
  <div class="stats-grid">
    <div class="stat-card"><div class="icon">▣</div><span class="label">Ραντεβού σήμερα</span><div class="value">${todayAp}</div></div>
    <div class="stat-card"><div class="icon">♙</div><span class="label">Ενεργοί πελάτες</span><div class="value">${state.clients.length}</div></div>
    <div class="stat-card"><div class="icon">⌁</div><span class="label">Μετρήσεις Tanita</span><div class="value">${state.measurements.length}</div></div>
    <div class="stat-card"><div class="icon">€</div><span class="label">Καθαρό αποτέλεσμα</span><div class="value">${money(income-expenses)}</div></div>
  </div>
  <div class="section-title"><h2>Γρήγορες ενέργειες</h2></div>
  <div class="quick-grid">
    <button class="quick" id="quickClient">＋<strong>Νέος Πελάτης</strong></button>
    <button class="quick" data-go="appointments">▣<strong>Νέο Ραντεβού</strong></button>
    <button class="quick" data-go="tanita">◉<strong>Tanita Μέτρηση</strong></button>
    <button class="quick" data-go="planner">✓<strong>Νέα Εργασία</strong></button>
  </div>
  <div class="section-title"><h2>Χρειάζονται προσοχή</h2><button class="link-btn" data-go="clients">Όλοι</button></div>
  <div class="list">${due?state.clients.filter(c=>c.nextFollowUp&&c.nextFollowUp<=today()).slice(0,4).map(clientRow).join(''):'<div class="card empty">Δεν υπάρχουν εκκρεμή follow-ups 🎉</div>'}</div>`;
}

function clientRow(c){
  const m=lastMeasurement(c.id);
  const overdue=c.nextFollowUp&&c.nextFollowUp<=today();
  return `<button class="client-row" data-client="${c.id}">
    <div class="avatar">${initials(c.name)}</div>
    <div class="client-main"><b>${esc(c.name)}</b><span>${esc(c.status||'Ενεργός')} · ${m?`Τελευταία Tanita: ${esc(m.date)}`:'Χωρίς Tanita'}</span></div>
    <span class="status ${overdue?'warn':''}">${overdue?'Follow-up':'Ενεργός'}</span><span class="arrow">›</span>
  </button>`;
}

function clients(){
  return `<div class="page-head"><div><h1>Καρτέλες Μελών</h1><p class="muted">Όλα τα στοιχεία κάθε ανθρώπου σε μία καρτέλα.</p></div><button class="primary" id="quickClient">＋ Νέος Πελάτης</button></div>
  <div class="searchbar"><input id="clientSearch" placeholder="Αναζήτηση ονόματος, τηλεφώνου ή email..."></div>
  <div class="list" id="clientList">${state.clients.length?state.clients.map(clientRow).join(''):'<div class="card empty">Δεν υπάρχουν πελάτες ακόμη. Πρόσθεσε τον πρώτο σου πελάτη.</div>'}</div>`;
}

function clientDetail(){
  const c=client(currentClientId);
  if(!c)return `<div class="empty">Ο πελάτης δεν βρέθηκε.</div>`;
  const ms=state.measurements.filter(m=>m.clientId===c.id).sort((a,b)=>b.date.localeCompare(a.date));
  const m=ms[0];
  const aps=state.appointments.filter(a=>a.clientId===c.id).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  const orders=state.orders.filter(o=>o.clientId===c.id).sort((a,b)=>b.date.localeCompare(a.date));

  return `<div class="page-head">
    <div><button class="link-btn" data-go="clients">‹ Πίσω στους πελάτες</button>
    <h1>${esc(c.name)}</h1><p class="muted">${esc(c.phone||'')} ${c.email?' · '+esc(c.email):''}</p></div>
    <div class="actions"><button class="secondary" id="printClient">📄 PDF / Εκτύπωση</button><button class="danger-btn" id="deleteClient">Διαγραφή</button></div>
  </div>

  <div class="profile-hero">
    <div class="avatar large">${initials(c.name)}</div>
    <div class="profile-main"><div class="eyebrow">ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ</div><h2>${esc(c.name)}</h2>
      <div class="profile-meta"><span>${esc(c.status||'Ενεργός πελάτης')}</span><span>Έναρξη: ${esc(c.startDate||c.createdAt||'—')}</span><span>Follow-up: ${esc(c.nextFollowUp||'—')}</span></div>
    </div>
  </div>

  <div class="tabs client-tabs">
    <button class="tab active" data-detail-tab="overview">Προσωπική Αξιολόγηση</button>
    <button class="tab" data-detail-tab="appointments">Ραντεβού</button>
    <button class="tab" data-detail-tab="membership">Μέλος / Συνεργάτης</button>
    <button class="tab" data-detail-tab="measurements">Tanita</button>
    <button class="tab" data-detail-tab="nutrition">Διατροφή</button>
    <button class="tab" data-detail-tab="orders">Παραγγελίες / Πληρωμές</button>
    <button class="tab" data-detail-tab="notes">Σημειώσεις</button>
  </div>

  <div id="detailContent">${detailOverview(c,m,ms,aps,orders)}</div>`;
}

function detailOverview(c,m,ms){
  return `<div class="evaluation-title">ΠΡΟΣΩΠΙΚΗ ΑΞΙΟΛΟΓΗΣΗ</div>
  <div class="metric-grid">
    <div class="metric"><span>Βάρος</span><b>${m?esc(m.weight)+' kg':'—'}</b></div>
    <div class="metric"><span>Σωματικό λίπος</span><b>${m?esc(m.fat||'—')+' %':'—'}</b></div>
    <div class="metric"><span>Μυϊκή μάζα</span><b>${m?esc(m.muscle||'—')+' kg':'—'}</b></div>
    <div class="metric"><span>Metabolic Age</span><b>${m?esc(m.metabolicAge||'—'):'—'}</b></div>
  </div>
  <div class="two-col">
    <div class="card form-card"><h2>Στοιχεία & Επικοινωνία</h2>
      <p><b>Τηλέφωνο:</b> ${esc(c.phone||'—')}</p><p><b>Email:</b> ${esc(c.email||'—')}</p><p><b>Ημερομηνία γέννησης:</b> ${esc(c.birthDate||'—')}</p>
      <p><b>Κατάσταση:</b> ${esc(c.status||'—')}</p>
    </div>
    <div class="card form-card"><h2>Στόχος</h2>
      <textarea id="clientGoal" data-save-field="goal" data-client-id="${c.id}" placeholder="Ποιος είναι ο βασικός στόχος του πελάτη;">${esc(c.goal||'')}</textarea>
      <button class="primary save-client-field" data-field="goal">Αποθήκευση στόχου</button>
    </div>
  </div>
  <div class="card form-card"><h2>Τρέχουσα εικόνα & παρατηρήσεις αξιολόγησης</h2>
    <textarea id="evaluationNotes" data-save-field="evaluationNotes" data-client-id="${c.id}" placeholder="Τι παρατήρησες στην αξιολόγηση; ανάγκες, προτεραιότητες, επόμενα βήματα...">${esc(c.evaluationNotes||'')}</textarea>
    <button class="primary save-client-field" data-field="evaluationNotes">Αποθήκευση αξιολόγησης</button>
  </div>
  <div class="card form-card"><h2>Τελευταία Tanita</h2>${m?`<div class="metric-grid compact">
    <div class="metric"><span>Νερό</span><b>${esc(m.water||'—')}%</b></div><div class="metric"><span>Σπλαχνικό</span><b>${esc(m.visceral||'—')}</b></div>
    <div class="metric"><span>Οστική μάζα</span><b>${esc(m.bone||'—')}</b></div><div class="metric"><span>Θερμίδες</span><b>${esc(m.calories||'—')}</b></div>
  </div>`:'<div class="empty">Δεν υπάρχει μέτρηση ακόμη.</div>'}</div>`;
}

function detailAppointments(c){
  const aps=state.appointments.filter(a=>a.clientId===c.id).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  return `<div class="section-title"><h2>Ραντεβού ${esc(c.name)}</h2><button class="primary" id="newClientAppointment">＋ Νέο ραντεβού</button></div>
  <div class="list">${aps.map(a=>`<div class="client-row"><div class="avatar">▣</div><div class="client-main"><b>${esc(a.date)} · ${esc(a.time||'—')}</b><span>${esc(a.type||'Συνάντηση')} · ${esc(a.notes||'')}</span></div><button class="danger-btn" data-del-ap="${a.id}">×</button></div>`).join('')||'<div class="card empty">Δεν υπάρχουν ραντεβού.</div>'}</div>`;
}

function detailMembership(c){
  return `<div class="card form-card"><h2>Κατάσταση μέλους / συνεργάτη</h2>
    <label>Κατάσταση<select id="memberStatus"><option ${c.status==='Ενεργός πελάτης'?'selected':''}>Ενεργός πελάτης</option><option ${c.status==='Νέο μέλος'?'selected':''}>Νέο μέλος</option><option ${c.status==='Υποψήφιος συνεργάτης'?'selected':''}>Υποψήφιος συνεργάτης</option><option ${c.status==='Συνεργάτης'?'selected':''}>Συνεργάτης</option></select></label>
    <label>Στόχος συνεργασίας<textarea id="partnerGoal">${esc(c.partnerGoal||'')}</textarea></label>
    <label>Επόμενο βήμα<textarea id="partnerNext">${esc(c.partnerNext||'')}</textarea></label>
    <button class="primary" id="saveMembership">Αποθήκευση</button>
  </div>`;
}

function detailMeasurements(c){
  const ms=state.measurements.filter(m=>m.clientId===c.id).sort((a,b)=>b.date.localeCompare(a.date));
  return `<div class="section-title"><h2>Ιστορικό Tanita</h2><button class="primary" id="newClientMeasurement">＋ Νέα μέτρηση</button></div>
  <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Ημερομηνία</th><th>Βάρος</th><th>Λίπος</th><th>Μύες</th><th>Νερό</th><th>Σπλαχνικό</th></tr></thead><tbody>
  ${ms.map(m=>`<tr><td>${esc(m.date)}</td><td>${esc(m.weight||'—')} kg</td><td>${esc(m.fat||'—')}%</td><td>${esc(m.muscle||'—')} kg</td><td>${esc(m.water||'—')}%</td><td>${esc(m.visceral||'—')}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">Δεν υπάρχουν μετρήσεις.</td></tr>'}</tbody></table></div></div>`;
}

function detailNutrition(c){
  return `<div class="card form-card"><h2>Διατροφικό πρόγραμμα</h2>
    <label>Τρέχον πρόγραμμα<textarea id="nutritionPlan">${esc(c.nutritionPlan||'')}</textarea></label>
    <div class="two-col"><label>Ημερήσιος στόχος θερμίδων<input id="nutritionCalories" type="number" value="${esc(c.nutritionCalories||'')}"></label>
    <label>Ημερήσιος στόχος πρωτεΐνης (g)<input id="nutritionProtein" type="number" value="${esc(c.nutritionProtein||'')}"></label></div>
    <label>Παρατηρήσεις / συμμόρφωση<textarea id="nutritionNotes">${esc(c.nutritionNotes||'')}</textarea></label>
    <button class="primary" id="saveNutrition">Αποθήκευση διατροφικού προγράμματος</button>
  </div>`;
}

function detailOrders(c){
  const orders=state.orders.filter(o=>o.clientId===c.id).sort((a,b)=>b.date.localeCompare(a.date));
  return `<div class="section-title"><h2>Παραγγελίες & Πληρωμές</h2><button class="primary" id="newClientOrder">＋ Νέα καταχώρηση</button></div>
  <div class="list">${orders.map(o=>`<div class="client-row"><div class="avatar">€</div><div class="client-main"><b>${esc(o.description||'Παραγγελία')} · ${money(o.amount)}</b><span>${esc(o.date)} · ${esc(o.status||'Καταχωρήθηκε')}</span></div></div>`).join('')||'<div class="card empty">Δεν υπάρχουν παραγγελίες ή πληρωμές.</div>'}</div>`;
}

function detailNotes(c){
  return `<div class="card form-card"><h2>Κεντρικές σημειώσεις πελάτη</h2>
    <textarea id="clientNotes" style="min-height:260px">${esc(c.notes||'')}</textarea>
    <button class="primary" id="saveClientNotes">Αποθήκευση σημειώσεων</button>
  </div>`;
}

function tanita(){
  return `<div class="page-head"><div><h1>Tanita</h1><p class="muted">Μετρήσεις και ιστορικό ανά πελάτη.</p></div></div>
  <div class="card form-card"><form id="tanitaForm"><div class="two-col">
  <label>Πελάτης<select name="clientId" required><option value="">Επίλεξε πελάτη</option>${state.clients.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>
  <label>Ημερομηνία<input name="date" type="date" value="${today()}" required></label></div>
  <div class="metric-grid"><label>Βάρος (kg)<input name="weight" type="number" step=".1" required></label><label>Λίπος (%)<input name="fat" type="number" step=".1"></label><label>Μυϊκή μάζα (kg)<input name="muscle" type="number" step=".1"></label><label>Νερό (%)<input name="water" type="number" step=".1"></label></div>
  <div class="metric-grid"><label>Σπλαχνικό λίπος<input name="visceral" type="number" step=".1"></label><label>Μεταβολική ηλικία<input name="metabolicAge" type="number"></label><label>Οστική μάζα<input name="bone" type="number" step=".1"></label><label>Θερμίδες<input name="calories" type="number"></label></div>
  <div class="actions"><button class="primary">Αποθήκευση μέτρησης</button></div></form></div>
  <div class="card form-card"><h2>Ιστορικό μετρήσεων</h2><div class="table-wrap"><table class="table"><thead><tr><th>Ημερομηνία</th><th>Πελάτης</th><th>Βάρος</th><th>Λίπος</th><th>Μύες</th><th></th></tr></thead><tbody>
  ${state.measurements.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(m=>`<tr><td>${esc(m.date)}</td><td>${esc(client(m.clientId)?.name||'—')}</td><td>${esc(m.weight)} kg</td><td>${esc(m.fat||'—')}%</td><td>${esc(m.muscle||'—')} kg</td><td><button class="danger-btn" data-del-measure="${m.id}">Διαγραφή</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">Δεν υπάρχουν μετρήσεις.</td></tr>'}</tbody></table></div></div>`;
}

function appointments(){
  const aps=state.appointments.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  return `<div class="page-head"><div><h1>Ραντεβού</h1><p class="muted">Ημερήσιο πρόγραμμα και συναντήσεις.</p></div><button class="primary" id="newAppointment">＋ Νέο ραντεβού</button></div>
  <div class="list">${aps.map(a=>`<div class="client-row"><div class="avatar">▣</div><div class="client-main"><b>${esc(client(a.clientId)?.name||a.name||'Ραντεβού')}</b><span>${esc(a.date)} · ${esc(a.time||'—')} · ${esc(a.type||'Συνάντηση')}</span></div><button class="danger-btn" data-del-ap="${a.id}">×</button></div>`).join('')||'<div class="card empty">Δεν υπάρχουν ραντεβού.</div>'}</div>`;
}

function more(){
  return `<div class="page-head"><div><h1>Περισσότερα</h1><p class="muted">Όλα τα εργαλεία του Wellness CEO.</p></div></div>
  <div class="more-grid"><button class="more-item" data-go="planner">✓<b>CEO Planner</b><span>Καθημερινές εργασίες και στόχοι.</span></button>
  <button class="more-item" data-go="finance">€<b>Οικονομικά</b><span>Έσοδα, έξοδα και καθαρό αποτέλεσμα.</span></button>
  <button class="more-item" data-go="tanita">◉<b>Tanita</b><span>Μετρήσεις και ιστορικό.</span></button>
  <button class="more-item" data-go="backup">↕<b>Backup</b><span>Εξαγωγή και επαναφορά δεδομένων.</span></button></div>`;
}

function planner(){
  return `<div class="page-head"><div><h1>CEO Planner</h1><p class="muted">Οι καθημερινές ενέργειές σου.</p></div></div>
  <div class="card"><form id="taskForm"><div class="two-col"><input name="task" placeholder="Νέα εργασία..." required><input name="date" type="date" value="${today()}" required></div><div class="actions"><button class="primary">＋ Προσθήκη</button></div></form></div>
  <div class="card form-card"><h2>Εργασίες</h2>${state.tasks.map(t=>`<div class="client-row"><input type="checkbox" data-task="${t.id}" ${t.done?'checked':''} style="width:auto"><div class="client-main"><b style="${t.done?'text-decoration:line-through':''}">${esc(t.task)}</b><span>${esc(t.date)}</span></div></div>`).join('')||'<div class="empty">Δεν υπάρχουν εργασίες.</div>'}</div>`;
}

function finance(){
  const income=state.income.reduce((a,x)=>a+Number(x.amount||0),0),expenses=state.expenses.reduce((a,x)=>a+Number(x.amount||0),0);
  return `<div class="page-head"><div><h1>Οικονομικά</h1><p class="muted">Έσοδα, έξοδα και καθαρό αποτέλεσμα.</p></div></div>
  <div class="metric-grid"><div class="metric"><span>Έσοδα</span><b>${money(income)}</b></div><div class="metric"><span>Έξοδα</span><b>${money(expenses)}</b></div><div class="metric"><span>Καθαρό</span><b>${money(income-expenses)}</b></div><div class="metric"><span>Συναλλαγές</span><b>${state.income.length+state.expenses.length}</b></div></div>
  <div class="two-col form-card"><div class="card"><h2>＋ Έσοδο</h2><form id="incomeForm"><label>Περιγραφή<input name="description" required></label><label>Ποσό<input name="amount" type="number" step=".01" required></label><button class="primary">Καταχώρηση</button></form></div>
  <div class="card"><h2>− Έξοδο</h2><form id="expenseForm"><label>Περιγραφή<input name="description" required></label><label>Ποσό<input name="amount" type="number" step=".01" required></label><button class="primary">Καταχώρηση</button></form></div></div>`;
}

function backup(){
  return `<div class="page-head"><div><h1>Backup</h1><p class="muted">Τα δεδομένα παραμένουν στον browser σου.</p></div></div>
  <div class="card"><div class="actions"><button class="primary" id="exportBtn">⬇ Εξαγωγή JSON</button><label class="secondary">⬆ Εισαγωγή JSON<input id="importFile" type="file" accept=".json" hidden></label><button class="danger-btn" id="clearData">Διαγραφή όλων</button></div>
  <p class="mini muted">Κράτησε ένα backup σε ασφαλές σημείο.</p></div>`;
}

function openAppointmentForm(clientId=null){
  const options=state.clients.map(c=>`<option value="${c.id}" ${clientId===c.id?'selected':''}>${esc(c.name)}</option>`).join('');
  const d=document.createElement('dialog');
  d.innerHTML=`<form id="appointmentForm"><div class="dialog-head"><h2>Νέο ραντεβού</h2><button type="button" class="icon-btn close-temp">×</button></div>
  <label>Πελάτης<select name="clientId" required><option value="">Επίλεξε πελάτη</option>${options}</select></label>
  <div class="two-col"><label>Ημερομηνία<input name="date" type="date" value="${today()}" required></label><label>Ώρα<input name="time" type="time" required></label></div>
  <label>Τύπος<select name="type"><option>Προσωπική αξιολόγηση</option><option>Follow-up</option><option>Tanita</option><option>Παρουσίαση</option><option>Συνάντηση</option></select></label>
  <label>Σημειώσεις<textarea name="notes"></textarea></label>
  <div class="dialog-actions"><button type="button" class="secondary close-temp">Ακύρωση</button><button class="primary">Αποθήκευση</button></div></form>`;
  document.body.appendChild(d);d.showModal();
  d.querySelectorAll('.close-temp').forEach(b=>b.onclick=()=>{d.close();d.remove()});
  d.querySelector('#appointmentForm').onsubmit=e=>{
    e.preventDefault();const f=new FormData(e.target);
    state.appointments.push({id:uid(),...Object.fromEntries(f)});save();d.close();d.remove();
    if(clientId){render('clientDetail')}else render('appointments');
  };
}

function openOrderForm(clientId){
  const d=document.createElement('dialog');
  d.innerHTML=`<form id="orderForm"><div class="dialog-head"><h2>Νέα παραγγελία / πληρωμή</h2><button type="button" class="icon-btn close-temp">×</button></div>
  <label>Περιγραφή<input name="description" required placeholder="Προϊόντα / υπηρεσία"></label>
  <div class="two-col"><label>Ποσό (€)<input name="amount" type="number" step=".01" required></label><label>Ημερομηνία<input name="date" type="date" value="${today()}" required></label></div>
  <label>Κατάσταση<select name="status"><option>Καταχωρήθηκε</option><option>Πληρώθηκε</option><option>Εκκρεμεί</option><option>Ολοκληρώθηκε</option></select></label>
  <div class="dialog-actions"><button type="button" class="secondary close-temp">Ακύρωση</button><button class="primary">Αποθήκευση</button></div></form>`;
  document.body.appendChild(d);d.showModal();
  d.querySelectorAll('.close-temp').forEach(b=>b.onclick=()=>{d.close();d.remove()});
  d.querySelector('#orderForm').onsubmit=e=>{
    e.preventDefault();const f=new FormData(e.target);
    state.orders.push({id:uid(),clientId,...Object.fromEntries(f),amount:Number(f.get('amount')||0)});save();d.close();d.remove();render('clientDetail');
  };
}

function openMeasurementForm(clientId){
  const d=document.createElement('dialog');
  d.innerHTML=`<form id="miniTanita"><div class="dialog-head"><h2>Νέα μέτρηση Tanita</h2><button type="button" class="icon-btn close-temp">×</button></div>
  <div class="two-col"><label>Ημερομηνία<input name="date" type="date" value="${today()}" required></label><label>Βάρος (kg)<input name="weight" type="number" step=".1" required></label></div>
  <div class="metric-grid"><label>Λίπος (%)<input name="fat" type="number" step=".1"></label><label>Μύες (kg)<input name="muscle" type="number" step=".1"></label><label>Νερό (%)<input name="water" type="number" step=".1"></label><label>Σπλαχνικό λίπος<input name="visceral" type="number" step=".1"></label></div>
  <div class="metric-grid"><label>Μεταβολική ηλικία<input name="metabolicAge" type="number"></label><label>Οστική μάζα<input name="bone" type="number" step=".1"></label><label>Θερμίδες<input name="calories" type="number"></label></div>
  <div class="dialog-actions"><button type="button" class="secondary close-temp">Ακύρωση</button><button class="primary">Αποθήκευση</button></div></form>`;
  document.body.appendChild(d);d.showModal();
  d.querySelectorAll('.close-temp').forEach(b=>b.onclick=()=>{d.close();d.remove()});
  d.querySelector('#miniTanita').onsubmit=e=>{
    e.preventDefault();const f=new FormData(e.target);
    state.measurements.push({id:uid(),clientId,...Object.fromEntries(f)});save();d.close();d.remove();render('clientDetail');
  };
}

function bind(){
  $$('[data-go]').forEach(b=>b.onclick=()=>nav(b.dataset.go));
  $$('[data-client]').forEach(b=>b.onclick=()=>{currentClientId=b.dataset.client;render('clientDetail')});
  $('#quickClient')?.addEventListener('click',()=>$('#clientDialog').showModal());
  $('[data-close-dialog]')?.addEventListener('click',()=>$('#clientDialog').close());

  $('#clientForm')?.addEventListener('submit',e=>{
    e.preventDefault();const f=new FormData(e.target);
    state.clients.push({id:uid(),createdAt:today(),...Object.fromEntries(f)});save();
    e.target.reset();$('#clientDialog').close();render('clients');
  });

  $('#clientSearch')?.addEventListener('input',e=>{
    const q=e.target.value.toLowerCase();
    $('#clientList').innerHTML=state.clients.filter(c=>(c.name+' '+(c.phone||'')+' '+(c.email||'')).toLowerCase().includes(q)).map(clientRow).join('')||'<div class="card empty">Δεν βρέθηκε πελάτης.</div>';
    bind();
  });

  $('#deleteClient')?.addEventListener('click',()=>{
    if(confirm('Να διαγραφεί ο πελάτης;')){
      state.clients=state.clients.filter(c=>c.id!==currentClientId);
      state.measurements=state.measurements.filter(m=>m.clientId!==currentClientId);
      state.appointments=state.appointments.filter(a=>a.clientId!==currentClientId);
      state.orders=state.orders.filter(o=>o.clientId!==currentClientId);
      save();nav('clients');
    }
  });

  $('#printClient')?.addEventListener('click',()=>window.print());

  $$('.client-tabs .tab').forEach(tab=>tab.onclick=()=>{
    $$('.client-tabs .tab').forEach(t=>t.classList.remove('active'));tab.classList.add('active');
    const c=client(currentClientId);
    const key=tab.dataset.detailTab;
    $('#detailContent').innerHTML=key==='overview'?detailOverview(c,lastMeasurement(c.id),state.measurements.filter(m=>m.clientId===c.id)):
      key==='appointments'?detailAppointments(c):
      key==='membership'?detailMembership(c):
      key==='measurements'?detailMeasurements(c):
      key==='nutrition'?detailNutrition(c):detailNotes(c);
    if(key==='orders')$('#detailContent').innerHTML=detailOrders(c);
    bind();
  });

  $$('.save-client-field').forEach(b=>b.onclick=()=>{
    const field=b.dataset.field, el=$(`[data-save-field="${field}"]`);
    if(el){client(currentClientId)[field]=el.value;save();b.textContent='✓ Αποθηκεύτηκε';setTimeout(()=>b.textContent='Αποθήκευση',1000)}
  });

  $('#saveMembership')?.addEventListener('click',()=>{
    const c=client(currentClientId);c.status=$('#memberStatus').value;c.partnerGoal=$('#partnerGoal').value;c.partnerNext=$('#partnerNext').value;save();render('clientDetail');
  });

  $('#saveNutrition')?.addEventListener('click',()=>{
    const c=client(currentClientId);c.nutritionPlan=$('#nutritionPlan').value;c.nutritionCalories=$('#nutritionCalories').value;c.nutritionProtein=$('#nutritionProtein').value;c.nutritionNotes=$('#nutritionNotes').value;save();render('clientDetail');
  });

  $('#saveClientNotes')?.addEventListener('click',()=>{
    client(currentClientId).notes=$('#clientNotes').value;save();render('clientDetail');
  });

  $('#newClientAppointment')?.addEventListener('click',()=>openAppointmentForm(currentClientId));
  $('#newClientOrder')?.addEventListener('click',()=>openOrderForm(currentClientId));
  $('#newClientMeasurement')?.addEventListener('click',()=>openMeasurementForm(currentClientId));

  $('#newAppointment')?.addEventListener('click',()=>openAppointmentForm());
  $$('[data-del-ap]').forEach(b=>b.onclick=()=>{state.appointments=state.appointments.filter(a=>a.id!==b.dataset.delAp);save();render(currentClientId?'clientDetail':'appointments')});
  $('#newMeasurement')?.addEventListener('click',()=>nav('tanita'));

  $('#tanitaForm')?.addEventListener('submit',e=>{
    e.preventDefault();const f=new FormData(e.target);state.measurements.push({id:uid(),...Object.fromEntries(f)});save();render('tanita');
  });
  $$('[data-del-measure]').forEach(b=>b.onclick=()=>{state.measurements=state.measurements.filter(m=>m.id!==b.dataset.delMeasure);save();render('tanita')});

  $('#taskForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);state.tasks.push({id:uid(),task:f.get('task'),date:f.get('date'),done:false});save();render('planner')});
  $$('[data-task]').forEach(b=>b.onchange=()=>{const t=state.tasks.find(x=>x.id===b.dataset.task);if(t)t.done=b.checked;save();render('planner')});

  $('#incomeForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);state.income.push({id:uid(),description:f.get('description'),amount:f.get('amount'),date:today()});save();render('finance')});
  $('#expenseForm')?.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);state.expenses.push({id:uid(),description:f.get('description'),amount:f.get('amount'),date:today()});save();render('finance')});

  $('#exportBtn')?.addEventListener('click',()=>{
    const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nikoleta-wellness-ceo-backup.json';a.click();URL.revokeObjectURL(a.href);
  });
  $('#importFile')?.addEventListener('change',e=>{
    const file=e.target.files[0];if(!file)return;
    const r=new FileReader();r.onload=()=>{
      try{state={...structuredClone(initial),...JSON.parse(r.result)};save();render('backup');alert('Η εισαγωγή ολοκληρώθηκε.')}
      catch{alert('Μη έγκυρο αρχείο backup.')}
    };r.readAsText(file);
  });
  $('#clearData')?.addEventListener('click',()=>{if(confirm('Να διαγραφούν ΟΛΑ τα δεδομένα;')){state=structuredClone(initial);save();render('backup')}});

  $('#notifyBtn')?.addEventListener('click',()=>{
    const aps=state.appointments.filter(a=>a.date===today()).length;
    const f=state.clients.filter(c=>c.nextFollowUp&&c.nextFollowUp<=today()).length;
    alert(`Σήμερα έχεις ${aps} ραντεβού και ${f} follow-up που χρειάζονται προσοχή.`);
  });
}

$$('.bottom-nav button').forEach(b=>b.onclick=()=>nav(b.dataset.view));
render();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));